
import 'package:flutter/material.dart';

void main() => runApp(JalRakshakApp());

class JalRakshakApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'JalRakshak',
      home: Scaffold(
        appBar: AppBar(title: Text('JalRakshak')),
        body: Center(child: Text('Welcome Aqua Worker')),
      ),
    );
  }
}
